package com.wab.stafftools;

import com.wab.stafftools.commands.FreezeCommand;
import com.wab.stafftools.commands.GetFreezerCommand;
import com.wab.stafftools.listeners.FreezeInteractListener;
import com.wab.stafftools.listeners.FreezeMovementListener;
import com.wab.stafftools.managers.FreezeManager;
import org.bukkit.plugin.java.JavaPlugin;

public class StaffToolsPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        FreezeManager freezeManager = new FreezeManager();

        GetFreezerCommand getFreezerCommand = new GetFreezerCommand(this);
        getCommand("getfreezer").setExecutor(getFreezerCommand);
        getCommand("freeze").setExecutor(new FreezeCommand(freezeManager));

        getServer().getPluginManager().registerEvents(
                new FreezeInteractListener(freezeManager, getFreezerCommand.getKey()), this);
        getServer().getPluginManager().registerEvents(
                new FreezeMovementListener(freezeManager), this);

        getLogger().info("StaffToolsPlugin habilitado.");
    }

    @Override
    public void onDisable() {
        getLogger().info("StaffToolsPlugin deshabilitado.");
    }
}
