package com.wab.stafftools.commands;

import com.wab.stafftools.managers.FreezeManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FreezeCommand implements CommandExecutor {

    private final FreezeManager freezeManager;

    public FreezeCommand(FreezeManager freezeManager) {
        this.freezeManager = freezeManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("stafftools.admin")) {
            sender.sendMessage("§cNo tienes permiso.");
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage("§eUso: /freeze <jugador>");
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage("§cEse jugador no esta conectado.");
            return true;
        }

        boolean nowFrozen = freezeManager.toggle(target);
        sender.sendMessage(nowFrozen
                ? "§a" + target.getName() + " fue congelado."
                : "§a" + target.getName() + " fue descongelado.");
        return true;
    }
}
