package com.wab.stafftools.managers;

import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class FreezeManager {

    private final Set<UUID> frozen = new HashSet<>();

    public boolean isFrozen(Player player) {
        return frozen.contains(player.getUniqueId());
    }

    // Devuelve true si quedo congelado, false si quedo descongelado (toggle)
    public boolean toggle(Player player) {
        if (frozen.contains(player.getUniqueId())) {
            frozen.remove(player.getUniqueId());
            unfreezeEffects(player);
            broadcast(player, false);
            return false;
        } else {
            frozen.add(player.getUniqueId());
            freezeEffects(player);
            broadcast(player, true);
            return true;
        }
    }

    private void freezeEffects(Player player) {
        player.setWalkSpeed(0f);
        player.setFlySpeed(0f);
        player.sendTitle("§4§lHAS SIDO CONGELADO", "§fPor el staff", 10, 60, 20);
    }

    private void unfreezeEffects(Player player) {
        player.setWalkSpeed(0.2f);
        player.setFlySpeed(0.1f);
        player.sendTitle("§a§lHAS SIDO DESCONGELADO", "", 10, 40, 10);
    }

    private void broadcast(Player player, boolean nowFrozen) {
        String msg = nowFrozen
                ? "§cJugador §f" + player.getName() + " §cha sido congelado por el staff."
                : "§aJugador §f" + player.getName() + " §aha sido descongelado.";
        for (Player p : player.getServer().getOnlinePlayers()) {
            p.sendMessage("§c§l[WAB] §f" + msg);
        }
    }

    public void remove(Player player) {
        frozen.remove(player.getUniqueId());
    }
}
