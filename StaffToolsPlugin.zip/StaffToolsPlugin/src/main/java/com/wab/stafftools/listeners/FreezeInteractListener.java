package com.wab.stafftools.listeners;

import com.wab.stafftools.commands.GetFreezerCommand;
import com.wab.stafftools.managers.FreezeManager;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.ItemStack;

public class FreezeInteractListener implements Listener {

    private final FreezeManager freezeManager;
    private final NamespacedKey freezerKey;

    public FreezeInteractListener(FreezeManager freezeManager, NamespacedKey freezerKey) {
        this.freezeManager = freezeManager;
        this.freezerKey = freezerKey;
    }

    @EventHandler
    public void onClickPlayer(PlayerInteractEntityEvent event) {
        if (!(event.getRightClicked() instanceof Player)) return;

        Player staff = event.getPlayer();
        ItemStack item = staff.getInventory().getItemInMainHand();
        if (!GetFreezerCommand.isFreezer(item, freezerKey)) return;

        if (!staff.hasPermission("stafftools.admin")) return;

        event.setCancelled(true);
        Player target = (Player) event.getRightClicked();

        boolean nowFrozen = freezeManager.toggle(target);
        staff.sendMessage(nowFrozen
                ? "§a" + target.getName() + " fue congelado."
                : "§a" + target.getName() + " fue descongelado.");
    }
}
