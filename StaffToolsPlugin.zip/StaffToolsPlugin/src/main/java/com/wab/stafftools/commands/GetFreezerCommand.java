package com.wab.stafftools.commands;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Arrays;

public class GetFreezerCommand implements CommandExecutor {

    public static final String DISPLAY_NAME = "§b§lCongelador";
    private final NamespacedKey key;

    public GetFreezerCommand(JavaPlugin plugin) {
        this.key = new NamespacedKey(plugin, "freezer_tool");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("stafftools.admin")) {
            sender.sendMessage("§cNo tienes permiso.");
            return true;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cSolo un jugador puede usar este comando.");
            return true;
        }
        Player player = (Player) sender;

        ItemStack rod = new ItemStack(Material.BLAZE_ROD);
        ItemMeta meta = rod.getItemMeta();
        meta.setDisplayName(DISPLAY_NAME);
        meta.setLore(Arrays.asList("§7Clic derecho a un jugador", "§7para congelarlo/descongelarlo."));
        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
        rod.setItemMeta(meta);

        player.getInventory().addItem(rod);
        player.sendMessage("§c§l[WAB] §fRecibiste el Congelador.");
        return true;
    }

    public NamespacedKey getKey() {
        return key;
    }

    public static boolean isFreezer(ItemStack item, NamespacedKey key) {
        if (item == null || item.getType() != Material.BLAZE_ROD || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(key, PersistentDataType.BYTE);
    }
}
