# StaffTools Plugin para WAB 🧊

Plugin para servidores Paper/Spigot 1.21.x con herramientas de staff. Por ahora tiene el
sistema de congelar jugadores, con el mismo estilo visual que el plugin de Squid Game
(mensajes en §c§l[WAB], títulos grandes en pantalla) para que se vea todo parejo.

## Compilar

Igual que el plugin de Squid Game: ábrelo en IntelliJ IDEA como proyecto Maven
(`File > Open` → carpeta `StaffToolsPlugin`) y corre `package` desde la pestaña Maven.
El jar te queda en `target/StaffToolsPlugin.jar`.

## Instalar

Copia el jar a la carpeta `plugins/` del servidor y reinicia.

## Comandos

```
/getfreezer          <- (admin) te da el Congelador (blaze rod)
/freeze <jugador>     <- (admin) congela/descongela por comando (toggle)
```

Con el Congelador en la mano, clic derecho a un jugador lo congela; clic derecho otra vez
lo descongela (toggle, igual que el comando).

Un jugador congelado:
- No se puede mover (solo puede girar la cabeza)
- No puede romper ni poner bloques
- Le sale el título "HAS SIDO CONGELADO" en pantalla
- Sale un mensaje en el chat de todo el servidor

## Nota sobre permisos

Todos los comandos requieren el permiso `stafftools.admin` (por defecto lo tienen los OP).
